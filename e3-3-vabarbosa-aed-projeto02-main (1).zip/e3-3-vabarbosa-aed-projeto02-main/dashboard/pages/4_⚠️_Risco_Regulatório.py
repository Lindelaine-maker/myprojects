import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Configuração da página
st.set_page_config(
    page_title="i4DATA - Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Carregando os dados processados
try:
    df = pd.read_csv("./dashboard/dados.csv")
except FileNotFoundError:
    df = pd.read_csv("dados.csv")

df["data"] = df["data"].apply(lambda x: str(x) + "12" + "31")
df["data"] = pd.to_datetime(df["data"])

if "uf" in df.columns:
    # Obtém a lista única de UFs em ordena alfabetica
    lista_ufs = sorted(df["uf"].unique().tolist())
    # Insere a opção "todos" no início da lista
    lista_ufs.insert(0, "todos")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configurações")

    st.subheader("📍 Unidade Federativa (UF)")
    uf_selecionada = st.selectbox("Selecione o Estado (UF):", lista_ufs)

    # Período de análise
    st.subheader("📅 Período")
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Início", df["data"].min())
    with col2:
        end_date = st.date_input("Fim", df["data"].max())

    st.markdown("---")
    st.markdown("### 📊 Sobre o Projeto")
    st.info("""
    MVP desenvolvido pela Equipe 3.2 e 3.3 V.A. Barbosa 
    no programa C-Jovem Imersão.
    """)

# Filtro de período
mask = (df["data"] >= pd.to_datetime(start_date)) & (
    df["data"] <= pd.to_datetime(end_date)
)
df_filtered = df.loc[mask]
if uf_selecionada != "todos" and "uf" in df_filtered.columns:
    df_filtered = df_filtered[df_filtered["uf"] == uf_selecionada]

st.header("⚠️ Índice de Risco Regulatório")

# Calcular score de risco dinamicamente a partir dos dados
try:
    # Agrupar por fonte de energia e calcular estatísticas
    df_risco = (
        df_filtered.groupby("fonte_energia")
        .agg({"geracao_MWh": ["sum", "mean", "std"], "data": "count"})
        .reset_index()
    )

    df_risco.columns = [
        "fonte_energia",
        "geracao_total",
        "geracao_media",
        "geracao_std",
        "periodos",
    ]

    # Calcular score de risco baseado em:
    # 1. Volatilidade (desvio padrão)
    # 2. Consistência (coeficiente de variação)
    # 3. Estabilidade ao longo do tempo

    df_risco["cv"] = (df_risco["geracao_std"] / df_risco["geracao_media"]).fillna(0)

    # Score de risco: 0-100
    # Maior variabilidade = maior risco
    max_cv = df_risco["cv"].max()
    df_risco["score_risco"] = (df_risco["cv"] / (max_cv + 1e-6)) * 100

    # Adicionar análise por UF se selecionada "todos"
    if uf_selecionada == "todos" and "uf" in df_filtered.columns:
        df_risco_uf = (
            df_filtered.groupby("uf")
            .agg({"geracao_MWh": ["sum", "mean", "std"], "data": "count"})
            .reset_index()
        )

        df_risco_uf.columns = [
            "uf",
            "geracao_total",
            "geracao_media",
            "geracao_std",
            "periodos",
        ]
        df_risco_uf["cv"] = (
            df_risco_uf["geracao_std"] / df_risco_uf["geracao_media"]
        ).fillna(0)
        max_cv_uf = df_risco_uf["cv"].max()
        df_risco_uf["score_risco"] = (df_risco_uf["cv"] / (max_cv_uf + 1e-6)) * 100
        df_risco_uf.rename(columns={"uf": "fonte_energia"}, inplace=True)

        # Combinar análises
        st.subheader("📊 Risco por Unidade Federativa (UF)")

        # Tabela de risco por UF
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric(
                "UF com Menor Risco",
                df_risco_uf.loc[df_risco_uf["score_risco"].idxmin(), "fonte_energia"],
                f"{df_risco_uf['score_risco'].min():.1f}",
            )
        with col2:
            st.metric(
                "UF com Maior Risco",
                df_risco_uf.loc[df_risco_uf["score_risco"].idxmax(), "fonte_energia"],
                f"{df_risco_uf['score_risco'].max():.1f}",
            )
        with col3:
            st.metric("Risco Médio", f"{df_risco_uf['score_risco'].mean():.1f}")

        # Gráfico de barras com risco por UF
        fig_uf = px.bar(
            df_risco_uf,
            x="fonte_energia",
            y="score_risco",
            color="score_risco",
            color_continuous_scale="RdYlGn_r",
            title="Índice de Risco Regulatório por Unidade Federativa",
            labels={"fonte_energia": "UF", "score_risco": "Score de Risco"},
        )
        st.plotly_chart(fig_uf, use_container_width=True)

        st.markdown("---")

    # Exibir score por fonte de energia
    st.subheader("📊 Risco por Fonte de Energia")

    # Cards com riscos
    cols = st.columns(len(df_risco))
    for idx, (_, row) in enumerate(df_risco.iterrows()):
        with cols[idx]:
            fonte = row["fonte_energia"]
            score = row["score_risco"]

            # Definir cor baseado no score
            if score < 30:
                color = "🟢"
                nivel = "Baixo"
            elif score < 60:
                color = "🟡"
                nivel = "Médio"
            else:
                color = "🔴"
                nivel = "Alto"

            st.metric(f"{color} {fonte}", f"{score:.1f}", label_visibility="collapsed")
            st.progress(min(score / 100, 1.0))
            st.caption(f"Nível: **{nivel}**")

    st.markdown("---")

    # Gráfico de barras com ranking de risco
    fig = px.bar(
        df_risco.sort_values("score_risco", ascending=True),
        x="score_risco",
        y="fonte_energia",
        orientation="h",
        color="score_risco",
        color_continuous_scale="RdYlGn_r",
        title="Índice de Risco Regulatório por Fonte de Energia",
        labels={"fonte_energia": "Fonte de Energia", "score_risco": "Score de Risco"},
    )
    st.plotly_chart(fig, use_container_width=True)

    st.markdown("---")

    # Tabela completa com detalhamento
    st.subheader("📋 Detalhamento Completo por Fonte")

    df_display = df_risco[
        [
            "fonte_energia",
            "geracao_total",
            "geracao_media",
            "geracao_std",
            "cv",
            "score_risco",
        ]
    ].copy()
    df_display.columns = [
        "Fonte de Energia",
        "Geração Total (MWh)",
        "Geração Média (MWh)",
        "Desvio Padrão",
        "Coef. de Variação",
        "Score de Risco",
    ]
    df_display = df_display.sort_values("Score de Risco", ascending=False)

    st.dataframe(df_display, use_container_width=True)

    st.markdown("---")

    # Explicação metodológica
    with st.expander("ℹ️ Metodologia de Cálculo do Risco"):
        st.markdown("""
        O **Score de Risco Regulatório** é calculado da seguinte forma:
        
        1. **Coeficiente de Variação (CV)**: Razão entre desvio padrão e média
           - CV = Desvio Padrão / Média
           - Mede a variabilidade relativa dos dados
        
        2. **Score Normalizado**: Valor entre 0 e 100
           - Score = (CV / CV_máximo) × 100
           - Fontes com maior variabilidade recebem maior score
        
        3. **Interpretação**:
           - 🟢 **Baixo (< 30)**: Fonte estável e previsível
           - 🟡 **Médio (30-60)**: Fonte com volatilidade moderada
           - 🔴 **Alto (> 60)**: Fonte com alta volatilidade e risco
        
        **Contexto Regulatório**: Fontes com maior variabilidade apresentam maior risco 
        do ponto de vista regulatório, pois requerem maior flexibilidade operacional.
        """)

except Exception as e:
    st.error(f"❌ Erro ao processar dados de risco: {str(e)}")
    st.info("Verifique se os dados foram carregados corretamente.")
