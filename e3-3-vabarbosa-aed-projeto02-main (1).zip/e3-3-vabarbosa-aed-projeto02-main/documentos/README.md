# 📚 Documentação do Projeto i4DATA

Esta pasta contém toda a documentação, guias e materiais de referência do projeto.

## 📄 Documentos Principais

### Guias do Projeto

-   **Guide do Projeto.pdf** - Guia completo do MVP i4DATA

    -   Arquitetura técnica
    -   Plano de execução (10 semanas)
    -   Exemplos de código
    -   Fontes de dados
    -   Estrutura do projeto

-   **Escopo dos Projetos V. A. Barbosa.pdf** - Definição do escopo

    -   Projeto 01: Análise Exploratória de Dados
    -   Objetivos e entregáveis
    -   Cronograma

-   **Sugestão de codificação.pdf** - Boas práticas de código

## 📖 Conteúdo Abordado

### 1. Arquitetura e Estrutura

-   Organização de pastas
-   Fluxo de trabalho
-   Tecnologias utilizadas

### 2. Metodologia

-   ETL (Extract, Transform, Load)
-   Modelagem preditiva (Prophet, ARIMA)
-   Cálculo de risco regulatório
-   Dashboard interativo

### 3. Fontes de Dados

-   ANEEL (energia)
-   B3 (mercado financeiro)
-   Banco Central (indicadores)
-   Porto do Pecém
-   OFAC (sanções)

### 4. Cronograma

-   Planejamento semanal (Semanas 1-10)
-   Marcos e entregas
-   Critérios de validação

## 🎯 Para Novos Membros

1. Leia o **Guide do Projeto.pdf** primeiro
2. Revise o **Escopo** para entender objetivos
3. Consulte as **Sugestões de codificação**
4. Acompanhe o cronograma no README principal

## 📚 Materiais Complementares

-   [Prophet Documentation](https://facebook.github.io/prophet/)
-   [Pandas Guide](https://pandas.pydata.org/docs/)
-   [Streamlit Docs](https://docs.streamlit.io/)
-   [API Banco Central](https://dadosabertos.bcb.gov.br/)

## 🔄 Atualizações

Este README e os documentos podem ser atualizados conforme o projeto evolui.
Última atualização: Outubro 2025
