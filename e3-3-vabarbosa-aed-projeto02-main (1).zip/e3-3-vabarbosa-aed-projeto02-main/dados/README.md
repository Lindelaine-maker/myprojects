# 📊 Dados do Projeto i4DATA

Esta pasta contém os conjuntos de dados utilizados no projeto.

## 📁 Estrutura

### `/raw` - Dados Brutos

Dados originais baixados das fontes, sem modificações:

-   `energia_aneel.csv` - Dados de geração de energia (ANEEL)
-   `b3_egie3.csv` - Histórico de ações EGIE3 (B3)
-   `bcb_ipca.json` - Índice IPCA (Banco Central)
-   `porto_pecem.xlsx` - Movimentação portuária (Porto do Pecém)
-   `ofac_sanctions.csv` - Lista de sanções (OFAC)

**Nota:** Arquivos CSV/Excel não são versionados (ver `.gitignore`)

### `/processed` - Dados Processados

Dados limpos e transformados pelos scripts ETL:

-   `energia_clean.csv` - Energia com datas padronizadas
-   `forecast.csv` - Previsões do modelo Prophet
-   `risco.csv` - Índices de risco calculados
-   `feature_matrix.csv` - Matriz de features para modelagem

## 🔄 Pipeline de Dados

```text
raw/ → [ETL] → processed/ → [Modelagem] → outputs/
```

## 📥 Fontes de Dados

| Fonte       | Descrição            | Acesso                                                         |
| ----------- | -------------------- | -------------------------------------------------------------- |
| ANEEL       | Geração de energia   | [dadosabertos.aneel.gov.br](https://dadosabertos.aneel.gov.br) |
| B3          | Ações (via yfinance) | `yf.download("EGIE3.SA")`                                      |
| BCB         | Indicadores macro    | [API BCB](https://api.bcb.gov.br)                              |
| Porto Pecém | Movimentação         | [Transparência](https://www.portodopecem.com.br)               |
| OFAC        | Sanções              | [Treasury](https://www.treasury.gov/ofac)                      |

## ⚠️ Privacidade e LGPD

-   Não versionar dados pessoais ou sensíveis
-   Manter backups fora do repositório
-   Anonimizar dados quando necessário
-   Respeitar termos de uso das fontes

## 🚀 Como Obter os Dados

Execute o script de coleta:

```bash
python codigos/fetch_data.py
```

Ou baixe manualmente das fontes indicadas na documentação.
