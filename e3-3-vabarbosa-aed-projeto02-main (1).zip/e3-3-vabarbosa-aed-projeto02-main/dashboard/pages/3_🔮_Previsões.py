import warnings

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from prophet import Prophet
from statsmodels.tsa.arima.model import ARIMA

warnings.filterwarnings("ignore")

# Configuração da página
st.set_page_config(
    page_title="i4DATA - Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Carregando os dados processados
try:
    df = pd.read_csv("./dashboard/dados.csv")
except FileNotFoundError:
    df = pd.read_csv("dados.csv")

df["data"] = df["data"].apply(lambda x: str(x) + "12" + "31")
df["data"] = pd.to_datetime(df["data"])

if "uf" in df.columns:
    # Obtém a lista única de UFs em ordena alfabetica
    lista_ufs = sorted(df["uf"].unique().tolist())
    # Insere a opção "todos" no início da lista
    lista_ufs.insert(0, "todos")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configurações")

    st.subheader("📍 Unidade Federativa (UF)")
    uf_selecionada = st.selectbox("Selecione o Estado (UF):", lista_ufs)

    # Período de análise
    st.subheader("📅 Período")
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Início", df["data"].min())
    with col2:
        end_date = st.date_input("Fim", df["data"].max())

    st.markdown("---")
    st.markdown("### 📊 Sobre o Projeto")
    st.info("""
    MVP desenvolvido pela Equipe 3.2 e 3.3 V.A. Barbosa 
    no programa C-Jovem Imersão.
    """)

# Filtro de período
mask = (df["data"] >= pd.to_datetime(start_date)) & (
    df["data"] <= pd.to_datetime(end_date)
)
df_filtered = df.loc[mask]
if uf_selecionada != "todos" and "uf" in df_filtered.columns:
    df_filtered = df_filtered[df_filtered["uf"] == uf_selecionada]

# Agregação de dados para série temporal
df_ts = df_filtered.groupby("data")[["geracao_MWh"]].sum().reset_index()
df_ts = df_ts.sort_values("data")

# Remover linhas com valores zero ou nulos
df_ts = df_ts[(df_ts["geracao_MWh"] > 0) | (df_ts["geracao_MWh"].notna())]
df_ts = df_ts[df_ts["geracao_MWh"] != 0].reset_index(drop=True)

# Se ainda não tiver dados suficientes, usar todos os dados disponíveis
if len(df_ts) < 20:
    df_ts = df_filtered.groupby("data")[["geracao_MWh"]].sum().reset_index()
    df_ts = df_ts.sort_values("data").reset_index(drop=True)

st.header("🔮 Previsões de Geração de Energia")

# Debug: mostrar informações sobre os dados
with st.sidebar:
    st.markdown("---")
    st.subheader("📊 Debug - Dados Disponíveis")
    st.caption(f"Total de registros filtrados: {len(df_filtered)}")
    st.caption(f"Períodos únicos (anos): {len(df_ts)}")
    if len(df_ts) > 0:
        st.caption(
            f"Geração mín/máx: {df_ts['geracao_MWh'].min():.0f} / {df_ts['geracao_MWh'].max():.0f} MWh"
        )

if len(df_ts) > 10:  # Mínimo de dados para modelagem (reduzido para 10)
    # Seleção do modelo
    st.subheader("Selecione o Modelo de Previsão")
    col1, col2 = st.columns(2)

    with col1:
        usar_prophet = st.checkbox("Prophet (Facebook)", value=True)
    with col2:
        usar_arima = st.checkbox("ARIMA", value=True)

    periods_forecast = st.slider("Períodos de Previsão", 1, 10, 6)

    st.markdown("---")

    # ============ PROPHET ============
    if usar_prophet:
        st.subheader("📊 Previsão com Prophet")

        try:
            with st.spinner("Treinando modelo Prophet..."):
                # Preparar dados para Prophet
                prophet_df = df_ts.copy()
                prophet_df.columns = ["ds", "y"]

                # Treinar modelo
                model_prophet = Prophet(
                    yearly_seasonality=True,
                    weekly_seasonality=False,
                    daily_seasonality=False,
                    interval_width=0.95,
                    changepoint_prior_scale=0.05,
                )
                model_prophet.fit(prophet_df)

                # Fazer previsão
                future = model_prophet.make_future_dataframe(periods=periods_forecast)
                forecast = model_prophet.predict(future)

                # Gráfico da previsão
                fig_prophet = go.Figure()

                # Dados reais
                fig_prophet.add_trace(
                    go.Scatter(
                        x=prophet_df["ds"],
                        y=prophet_df["y"],
                        mode="lines",
                        name="Dados Históricos",
                        line=dict(color="darkblue", width=2),
                    )
                )

                # Previsão
                forecast_future = forecast[forecast["ds"] > prophet_df["ds"].max()]
                fig_prophet.add_trace(
                    go.Scatter(
                        x=forecast_future["ds"],
                        y=forecast_future["yhat"],
                        mode="lines",
                        name="Previsão",
                        line=dict(color="orange", width=2, dash="dash"),
                    )
                )

                # Intervalo de confiança
                fig_prophet.add_trace(
                    go.Scatter(
                        x=forecast_future["ds"],
                        y=forecast_future["yhat_upper"],
                        mode="lines",
                        line=dict(width=0),
                        showlegend=False,
                    )
                )

                fig_prophet.add_trace(
                    go.Scatter(
                        x=forecast_future["ds"],
                        y=forecast_future["yhat_lower"],
                        mode="lines",
                        line=dict(width=0),
                        fillcolor="rgba(255, 165, 0, 0.2)",
                        fill="tonexty",
                        name="Intervalo de Confiança (95%)",
                    )
                )

                fig_prophet.update_layout(
                    title="Previsão de Geração de Energia - Prophet",
                    xaxis_title="Data",
                    yaxis_title="Geração (MWh)",
                    height=500,
                    hovermode="x unified",
                    template="plotly_white",
                )

                st.plotly_chart(fig_prophet, use_container_width=True)

                # Estatísticas
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric(
                        "Previsão Média", f"{forecast_future['yhat'].mean():,.0f} MWh"
                    )
                with col2:
                    st.metric(
                        "Máximo Previsto", f"{forecast_future['yhat'].max():,.0f} MWh"
                    )
                with col3:
                    st.metric(
                        "Mínimo Previsto", f"{forecast_future['yhat'].min():,.0f} MWh"
                    )

                # Tabela de previsão
                with st.expander("📋 Detalhes da Previsão Prophet"):
                    forecast_display = forecast_future[
                        ["ds", "yhat", "yhat_lower", "yhat_upper"]
                    ].copy()
                    forecast_display.columns = [
                        "Data",
                        "Previsão",
                        "Limite Inferior",
                        "Limite Superior",
                    ]
                    st.dataframe(forecast_display, use_container_width=True)

        except Exception as e:
            st.error(f"❌ Erro ao treinar Prophet: {str(e)}")

    st.markdown("---")

    # ============ ARIMA ============
    if usar_arima:
        st.subheader("📊 Previsão com ARIMA")

        try:
            with st.spinner("Treinando modelo ARIMA..."):
                # Preparar dados para ARIMA
                series = df_ts["geracao_MWh"].values

                # Treinar modelo ARIMA(1,1,1)
                model_arima = ARIMA(series, order=(1, 1, 1))
                model_arima_fitted = model_arima.fit()

                # Fazer previsão
                forecast_arima = model_arima_fitted.get_forecast(steps=periods_forecast)
                conf_int = forecast_arima.conf_int(alpha=0.05)

                # Converter conf_int para DataFrame se for array
                if isinstance(conf_int, np.ndarray):
                    conf_int_lower = conf_int[:, 0]
                    conf_int_upper = conf_int[:, 1]
                else:
                    conf_int_lower = conf_int.iloc[:, 0].values
                    conf_int_upper = conf_int.iloc[:, 1].values

                # Criar DataFrame com previsões
                forecast_arima_df = pd.DataFrame(
                    {
                        "yhat": forecast_arima.predicted_mean,
                        "lower": conf_int_lower,
                        "upper": conf_int_upper,
                    }
                )

                # Criar datas para previsão
                last_date = df_ts["data"].max()
                forecast_dates = pd.date_range(
                    start=last_date + pd.Timedelta(days=365),
                    periods=periods_forecast,
                    freq="YS",
                )
                forecast_arima_df["ds"] = forecast_dates

                # Gráfico da previsão
                fig_arima = go.Figure()

                # Dados reais
                fig_arima.add_trace(
                    go.Scatter(
                        x=df_ts["data"],
                        y=df_ts["geracao_MWh"],
                        mode="lines",
                        name="Dados Históricos",
                        line=dict(color="darkgreen", width=2),
                    )
                )

                # Previsão
                fig_arima.add_trace(
                    go.Scatter(
                        x=forecast_arima_df["ds"],
                        y=forecast_arima_df["yhat"],
                        mode="lines",
                        name="Previsão",
                        line=dict(color="red", width=2, dash="dash"),
                    )
                )

                # Intervalo de confiança
                fig_arima.add_trace(
                    go.Scatter(
                        x=forecast_arima_df["ds"],
                        y=forecast_arima_df["upper"],
                        mode="lines",
                        line=dict(width=0),
                        showlegend=False,
                    )
                )

                fig_arima.add_trace(
                    go.Scatter(
                        x=forecast_arima_df["ds"],
                        y=forecast_arima_df["lower"],
                        mode="lines",
                        line=dict(width=0),
                        fillcolor="rgba(255, 0, 0, 0.2)",
                        fill="tonexty",
                        name="Intervalo de Confiança (95%)",
                    )
                )

                fig_arima.update_layout(
                    title="Previsão de Geração de Energia - ARIMA",
                    xaxis_title="Data",
                    yaxis_title="Geração (MWh)",
                    height=500,
                    hovermode="x unified",
                    template="plotly_white",
                )

                st.plotly_chart(fig_arima, use_container_width=True)

                # Estatísticas
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric(
                        "Previsão Média", f"{forecast_arima_df['yhat'].mean():,.0f} MWh"
                    )
                with col2:
                    st.metric(
                        "Máximo Previsto", f"{forecast_arima_df['yhat'].max():,.0f} MWh"
                    )
                with col3:
                    st.metric(
                        "Mínimo Previsto", f"{forecast_arima_df['yhat'].min():,.0f} MWh"
                    )

                # Métricas do modelo
                st.info(f"📈 **AIC do modelo ARIMA:** {model_arima_fitted.aic:.2f}")

                # Tabela de previsão
                with st.expander("📋 Detalhes da Previsão ARIMA"):
                    forecast_arima_display = forecast_arima_df[
                        ["ds", "yhat", "lower", "upper"]
                    ].copy()
                    forecast_arima_display.columns = [
                        "Data",
                        "Previsão",
                        "Limite Inferior",
                        "Limite Superior",
                    ]
                    st.dataframe(forecast_arima_display, use_container_width=True)

        except Exception as e:
            st.error(f"❌ Erro ao treinar ARIMA: {str(e)}")

    st.markdown("---")

    # ============ COMPARAÇÃO ============
    if usar_prophet and usar_arima:
        st.subheader("📊 Comparação entre Modelos")

        col1, col2 = st.columns(2)
        with col1:
            st.write("**Prophet** é melhor para:")
            st.markdown("""
            - Séries com sazonalidade forte
            - Dados com tendências múltiplas
            - Feriados e eventos anômalos
            - Menos dados históricos necessários
            """)

        with col2:
            st.write("**ARIMA** é melhor para:")
            st.markdown("""
            - Séries estacionárias
            - Autocarrelação forte
            - Séries mais estáveis
            - Dados com padrões simples
            """)
else:
    st.warning(
        "⚠️ Dados insuficientes para modelagem. Necessário pelo menos 10 períodos de dados históricos."
    )
    st.info(
        "💡 Dica: Tente expandir o período de análise ou selecionar 'todos' os estados."
    )
