import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Configuração da página
st.set_page_config(
    page_title="i4DATA - Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Carregando os dados processados
try:
    df = pd.read_csv("./dashboard/dados.csv")
except FileNotFoundError:
    df = pd.read_csv("dados.csv")

df["data"] = df["data"].apply(lambda x: str(x) + "12" + "31")
df["data"] = pd.to_datetime(df["data"])

if "uf" in df.columns:
    # Obtém a lista única de UFs em ordena alfabetica
    lista_ufs = sorted(df["uf"].unique().tolist())
    # Insere a opção "todos" no início da lista
    lista_ufs.insert(0, "todos")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configurações")

    st.subheader("📍 Unidade Federativa (UF)")
    uf_selecionada = st.selectbox(
        "Selecione o Estado (UF):", lista_ufs
    )

    # Período de análise
    st.subheader("📅 Período")
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Início", df["data"].min())
    with col2:
        end_date = st.date_input("Fim", df["data"].max())

    st.markdown("---")
    st.markdown("### 📊 Sobre o Projeto")
    st.info("""
    MVP desenvolvido pela Equipe 3.2 e 3.3 V.A. Barbosa 
    no programa C-Jovem Imersão.
    """)

# Filtro de período
mask = (df["data"] >= pd.to_datetime(start_date)) & (
    df["data"] <= pd.to_datetime(end_date)
)
df_filtered = df.loc[mask]
if uf_selecionada != "todos" and "uf" in df_filtered.columns:
        df_filtered = df_filtered[df_filtered["uf"] == uf_selecionada]
        
st.header("📊 Análise Exploratória de Dados (EDA)")

st.markdown("""
### Análises Planejadas:   
""")

st.markdown("""  
- 🗺️ Análise geográfica (por estado/região)
- 📊 Correlação entre variáveis
- 📉 Detecção de outliers e anomalias
- 🔄 Sazonalidade e tendências
- 📊 Comparação entre fontes de energia
""")

st.subheader("Série Temporal")
fig = px.line(
    df_filtered.groupby("data", as_index=False)["geracao_MWh"].sum(),
    x="data",
    y="geracao_MWh",
    title="Geração de Energia ao Longo do Tempo",
    labels={"data": "Data", "geracao_MWh": "Geração (MWh)"},
)
fig.update_layout(height=400)
st.plotly_chart(fig, use_container_width=True)

st.markdown("---")
st.markdown(
    "<h2 style='font-size: 26px; font-weight: 600;'>🌎 Análise geográfica (por estado/região)</h2>",
    unsafe_allow_html=True,
)
st.markdown("<br><br>", unsafe_allow_html=True)

# Contagem por UF
contagem_estados = df_filtered["uf"].value_counts()
top_estados = contagem_estados.head(10).reset_index()
top_estados.columns = ["UF", "Número de Registros"]

# Gráfico Plotly
fig_geo = px.bar(
    top_estados,
    x="UF",
    y="Número de Registros",
    title="Top 10 Estados com mais registros",
    labels={
        "UF": "Unidade Federativa (UF)",
        "Número de Registros": "Frequência de Registros",
    },
    color="Número de Registros",
    color_continuous_scale=px.colors.sequential.Viridis,
    template="plotly_dark",
)

fig_geo.update_layout(
    xaxis={"categoryorder": "total descending"},
    title={"x": 0.5, "xanchor": "center", "font": {"size": 22}},
    plot_bgcolor="#1e1e1e",
    paper_bgcolor="#0d0d0d",
    font=dict(color="#CCCCCC"),
)

# ---------------------------------------
# HEATMAP GEOGRÁFICO - TODOS OS ESTADOS
# ---------------------------------------

st.markdown("<br>", unsafe_allow_html=True)

# Agrega consumo por UF (todos os estados)
consumo_estados = (
    df_filtered.groupby("uf")["geracao_MWh"]
    .sum()
    .reset_index()
)

consumo_estados.columns = ["UF", "Consumo_Total_MWh"]

# GeoJSON oficial embutido no Plotly
import urllib.request, json
url = "https://raw.githubusercontent.com/codeforgermany/click_that_hood/master/public/data/brazil-states.geojson"
with urllib.request.urlopen(url) as response:
    brasil_geojson = json.loads(response.read())

# Criação do mapa
fig_map = px.choropleth(
    consumo_estados,
    geojson=brasil_geojson,
    locations="UF",
    featureidkey="properties.sigla",
    color="Consumo_Total_MWh",
    color_continuous_scale="OrRd",
    hover_name="UF",
    template="plotly_dark",
    title="Frequência de Consumo (MWh) - Energia gerada por cada Estado",
)

fig_map.update_geos(
    fitbounds="locations",
    visible=False
)

fig_map.update_layout(
    height=550,
    margin=dict(l=0, r=0, t=60, b=0),
    paper_bgcolor="#0d0d0d",
    plot_bgcolor="#1e1e1e",
    font=dict(color="#FFFFFF"),
    title=dict(x=0.5, xanchor="center", font=dict(size=22))  # CENTRALIZADO
)

st.plotly_chart(fig_map, use_container_width=True)



# Exibir no Streamlit
st.plotly_chart(fig_geo, use_container_width=True)

# HEATMAP DE CORRELAÇÃO
st.markdown("---")
st.markdown(
    "<h2 style='font-size: 26px; font-weight: 600;'>🗺️Heatmap (de correlação)</h2>",
    unsafe_allow_html=True,
)
st.markdown("<br><br>", unsafe_allow_html=True)

cols = [
    "potencia_mw",
    "geracao_MWh",
    "participacao_distribuidora",
    "participacao_classe",
    "participacao_brasil",
]

df_sel = df_filtered[cols]

corr = df_sel.corr().round(2)

fig_heatmap = px.imshow(
    corr,
    text_auto=True,
    color_continuous_scale="RdBu",
    aspect="auto",
    title="Matriz de Correlação (Heatmap)",
)
fig_heatmap.update_layout(template="plotly_dark", font=dict(size=18))

st.plotly_chart(fig_heatmap, use_container_width=True)

st.markdown("---")
st.markdown(
    "<h2 style='font-size: 26px; font-weight: 600;'>⚡Sazonalidade e tendências</h2>",
    unsafe_allow_html=True,
)

st.markdown("<br><br>", unsafe_allow_html=True)

# --- 2. Preparação de Dados e Contagem de Linhas ---
# Captura o número de linhas
row_count = len(df_filtered)

# Agrupar os dados e somar a Geração (MWh) por Distribuidora
agregado_distribuidoras = df_filtered.groupby("distribuidora")["geracao_MWh"].sum()

# Selecionar as 10 empresas com a maior produção
top_10_distribuidoras = (
    agregado_distribuidoras.sort_values(ascending=False).head(10).reset_index()
)
top_10_distribuidoras.columns = ["Distribuidora", "Geração Total (MWh)"]

# --- 3. Criar o gráfico de barras interativo com Plotly Express (Tema Escuro) ---
title="Top 10 Distribuidoras por Geração Total de Energia (MWh)"

fig_distribuidora = px.bar(
    top_10_distribuidoras,
    x="Distribuidora",
    y="Geração Total (MWh)",
    title=title,
    labels={
        "Distribuidora": "Distribuidora de Energia",
        "Geração Total (MWh)": "Geração Acumulada (MWh)",
    },
    color="Geração Total (MWh)",
    color_continuous_scale=px.colors.sequential.Turbo_r,
    template="plotly_dark",
)

# --- 4. Ajustar o layout e ADICIONAR A ANOTAÇÃO (Legenda) ---
fig_distribuidora.update_layout(
    xaxis={"categoryorder": "total descending"},
    hovermode="x unified",
    font=dict(family="Arial, sans-serif", size=12, color="white"),
    title_font_color="white",
    title_font_size=18,
    plot_bgcolor="black",
    paper_bgcolor="black",
    # NOVIDADE: Adiciona a contagem de linhas como uma anotação de rodapé
    annotations=[
        dict(
            text=f"Fonte: Dados de {row_count} linhas utilizadas para a análise.",  # O texto da anotação
            showarrow=False,  # Não mostra seta apontando para o gráfico
            xref="paper",  # Referência horizontal: posição relativa ao "papel" do gráfico
            yref="paper",  # Referência vertical: posição relativa ao "papel" do gráfico
            x=0.0,  # Posição X (0.0 = canto esquerdo)
            y=-0.2,  # Posição Y (abaixo do eixo X, ajuste este valor se necessário)
            font=dict(
                size=10,
                color="lightgray",  # Cor mais discreta
            ),
            align="left",
        )
    ],
)

# --- 5. Ajuste fino das barras e eixos (Cores do Grid) ---
fig_distribuidora.update_traces(marker_line_width=0, opacity=0.9)
fig_distribuidora.update_xaxes(showgrid=False, color="lightgray")
fig_distribuidora.update_yaxes(showgrid=True, gridcolor="gray", color="lightgray")

# Exibir no Streamlit
st.plotly_chart(fig_distribuidora, use_container_width=True)

# --- 6. Criar o Gráfico de Rosca (Donut Chart) com Plotly Express ---

title_rosca = "Participação Percentual das Top 10 Distribuidoras na Geração Total"

# O Plotly Express Pie/Donut é perfeito para mostrar a proporção
fig_rosca = px.pie(
    top_10_distribuidoras,
    values='Geração Total (MWh)',
    names='Distribuidora',
    title=title_rosca,
    hole=.3, # Define o tamanho do "buraco" para transformá-lo em um Rosca (Donut)
    color_discrete_sequence=px.colors.sequential.Turbo, # Usa a mesma sequência de cores (ou similar)
    template="plotly_dark",
)

# --- 7. Ajustar Rótulos, Layout e Estilo do Rosca ---

# Atualiza os traços para mostrar o percentual e o nome no gráfico
fig_rosca.update_traces(
    textinfo='percent+label', 
    marker=dict(line=dict(color='#000000', width=1)), # Adiciona uma linha preta para separar as fatias
    # O hoverinfo já é padrão, mas você pode especificar: hoverinfo='label+percent+value'
)

# Ajustes de layout para manter o tema escuro e a fonte consistente
fig_rosca.update_layout(
    font=dict(family="Arial, sans-serif", size=15, color="white"),
    title_font_color="white",
    title_font_size=20,
    plot_bgcolor="black",
    paper_bgcolor="black",
    legend_title_text="Distribuidoras",
    # Posiciona a legenda para melhor visualização
    legend=dict(
        orientation="v", # vertical
        yanchor="bottom",
        y=-0.005,
        xanchor="center",
        x=1.5
    )
)

# Exibir o Gráfico de Rosca no Streamlit
st.plotly_chart(fig_rosca, use_container_width=True)

st.markdown("---")
st.markdown(
    "<h2 style='font-size: 26px; font-weight: 600;'>💡 Comparação entre fontes de energia</h2>",
    unsafe_allow_html=True,
)
st.markdown("<br><br>", unsafe_allow_html=True)

labels = ["Fotovoltaica", "Termelétrica", "Eólica", "Hidro"]
counts = df["fonte_energia"].value_counts()
values = (counts/len(df)*100).round(2)

cores_neon_suave = ["#509e41", "#c02c20", "#304878", "#e88700"]

fig_fontes = go.Figure(
    data=[
        go.Pie(
            labels=labels,
            values=values,
            textinfo="percent+label",
            textfont=dict(color="#FFFFFF"),  # <<< letras brancas
            marker=dict(colors=cores_neon_suave),
            hoverinfo="label+percent+value",
            hole=0,
        )
    ]
)

fig_fontes.update_layout(
    title=dict(
        text="Fontes de Energia",
        font=dict(size=22, family="Arial", color="#f4f8e6"),
        x=0.0,
        xanchor="left",
    ),
    legend=dict(
        orientation="v",
        x=1.02,
        y=0.95,
        font=dict(size=12, color="#FFFFFF"),  # legenda branca
    ),
    paper_bgcolor="#131313",
    plot_bgcolor="#131313",
    margin=dict(t=80, b=20, l=20, r=150),
)

# Exibir no Streamlit
st.plotly_chart(fig_fontes, use_container_width=True)

fig_barras = go.Figure(
    data=[
        go.Bar(
            x=labels,
            y=values,
            marker_color=cores_neon_suave[:len(labels)],
            text=[f"{v:.2f}%" for v in values],
            textposition="auto",
            hovertemplate="<b>%{x}</b><br>%{y:.2f}%<extra></extra>",
        )
    ]
)

fig_barras.update_layout(
    title=dict(
        text="Fontes de Energia - Distribuição em Barras",
        font=dict(size=22, family="Arial", color="#f4f8e6"),
        x=0.0,
        xanchor="left",
    ),
    xaxis=dict(
        title="Fonte de Energia",
        showgrid=False,
        linecolor="#444444",
        tickfont=dict(color="#FFFFFF"),
        title_font=dict(color="#f4f8e6")
    ),
    yaxis=dict(
        title="Porcentagem (%)",
        gridcolor="#444444",
        linecolor="#444444",
        tickfont=dict(color="#FFFFFF"),
        title_font=dict(color="#f4f8e6")
    ),
    paper_bgcolor="#131313",
    plot_bgcolor="#131313",
    margin=dict(t=80, b=20, l=20, r=20),
    font=dict(color="#FFFFFF")
)

# Exibir no Streamlit
st.plotly_chart(fig_barras, use_container_width=True)

# Footer
st.markdown("---")
st.markdown(
    """
<div style='text-align: center'>
    <p>🚀 Desenvolvido pela <strong>Equipe 3.2 e 3.3  V.A. Barbosa</strong> | C-Jovem Imersão 2025</p>
    <p>
        <a href="https://github.com/capacitabrasil/e3-3-vabarbosa-cr-projeto02" target="_blank">📁 GitHub</a> • 
        <a href="./documentos" target="_blank">📚 Documentação</a> • 
        <a href="./notebooks" target="_blank">📓 Notebooks</a>
    </p>
</div>
""",
    unsafe_allow_html=True,
)