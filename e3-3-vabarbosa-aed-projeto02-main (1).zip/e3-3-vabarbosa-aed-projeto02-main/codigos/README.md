# 💻 Códigos Python - Scripts do Projeto

Esta pasta contém os scripts Python reutilizáveis desenvolvidos ao longo do projeto.

## 📁 Estrutura de Scripts

### ETL (Extract, Transform, Load)

-   `etl.py` - Pipeline principal de limpeza e transformação de dados
-   `fetch_data.py` - Scripts para baixar dados das fontes (ANEEL, B3, BCB)

### Modelagem Preditiva

-   `prophet_model.py` - Modelo de previsão com Prophet
-   `arima_model.py` - Modelo ARIMA para séries temporais
-   `risk_score.py` - Cálculo do índice de risco regulatório

### Utilitários

-   `utils.py` - Funções auxiliares reutilizáveis
-   `config.py` - Configurações e constantes do projeto
-   `validators.py` - Funções de validação de dados

## 🎯 Boas Práticas

-   Cada script deve ter docstrings descritivas
-   Use type hints para melhor legibilidade
-   Separe configurações em arquivos específicos
-   Teste funções críticas antes de usar em produção
-   Mantenha código modular e reutilizável

## 🚀 Exemplos de Uso

```python
# ETL
from etl import clean_energy_data
df_clean = clean_energy_data('dados/raw/energia_aneel.csv')

# Modelagem
from prophet_model import forecast_energy
predictions = forecast_energy(df_clean, periods=180)

# Risco
from risk_score import calculate_risk
risk = calculate_risk(df_clean)
```

## 📝 Desenvolvimento Incremental

Os scripts serão desenvolvidos gradualmente conforme o cronograma de 10 semanas do projeto.
