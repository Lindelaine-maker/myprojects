"""
Configurações do Projeto i4DATA
================================

Este arquivo contém constantes e configurações utilizadas em todo o projeto.
"""

import os
from pathlib import Path

# Diretórios do Projeto
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "dados"
RAW_DATA_DIR = DATA_DIR / "raw"
PROCESSED_DATA_DIR = DATA_DIR / "processed"
OUTPUTS_DIR = BASE_DIR / "outputs"
NOTEBOOKS_DIR = BASE_DIR / "notebooks"

# Criar diretórios se não existirem
for directory in [RAW_DATA_DIR, PROCESSED_DATA_DIR, OUTPUTS_DIR, NOTEBOOKS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# Arquivos de Dados
FILES = {
    "energia_raw": RAW_DATA_DIR / "energia_aneel.csv",
    "energia_processed": PROCESSED_DATA_DIR / "energia_clean.csv",
    "b3_ticker": RAW_DATA_DIR / "b3_egie3.csv",
    "forecast": PROCESSED_DATA_DIR / "forecast.csv",
    "risk": PROCESSED_DATA_DIR / "risco.csv",
}

# Configurações de Modelagem
PROPHET_CONFIG = {
    "seasonality_mode": "multiplicative",
    "yearly_seasonality": True,
    "weekly_seasonality": False,
    "daily_seasonality": False,
    "changepoint_prior_scale": 0.05,
}

FORECAST_PERIODS = 180  # dias (6 meses)

# Configurações de Visualização
PLOT_CONFIG = {
    "figsize": (12, 6),
    "style": "seaborn-v0_8-darkgrid",
    "color_palette": "husl",
    "dpi": 100,
}

# Configurações do Dashboard
DASHBOARD_CONFIG = {
    "title": "i4DATA - Inteligência Preditiva Ceará",
    "layout": "wide",
    "sidebar_state": "expanded",
}

# APIs e URLs
URLS = {
    "aneel_dados": "https://dadosabertos.aneel.gov.br/dataset",
    "bcb_api": "https://api.bcb.gov.br/dados/serie/bcdata.sgs",
    "ofac_sanctions": "https://www.treasury.gov/ofac/downloads/sdn.csv",
    "porto_pecem": "https://www.portodopecem.com.br/transparencia",
}

# Tickers da B3
TICKERS = {
    "egie3": "EGIE3.SA",  # Engie Brasil
    "petr4": "PETR4.SA",  # Petrobras
    "vale3": "VALE3.SA",  # Vale
}

# Período de análise padrão
DEFAULT_START_DATE = "2019-01-01"
DEFAULT_END_DATE = "2025-10-26"

# Colunas padronizadas
ENERGY_COLUMNS = {
    "Data": "data",
    "Geração (MWh)": "geracao_MWh",
    "Fonte": "fonte",
    "UF": "estado",
}

# Configurações de Risco
RISK_THRESHOLDS = {
    "low": 30,
    "medium": 60,
    "high": 100,
}

# Logging
LOG_FORMAT = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
LOG_LEVEL = "INFO"

# Encoding padrão para arquivos
DEFAULT_ENCODING = "utf-8"
FALLBACK_ENCODING = "latin1"

if __name__ == "__main__":
    print("🔧 Configurações do Projeto i4DATA")
    print(f"📁 Diretório base: {BASE_DIR}")
    print(f"📊 Diretório de dados: {DATA_DIR}")
    print(f"📈 Períodos de previsão: {FORECAST_PERIODS} dias")
