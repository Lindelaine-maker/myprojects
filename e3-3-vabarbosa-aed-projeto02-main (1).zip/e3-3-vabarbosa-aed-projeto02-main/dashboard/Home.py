import streamlit as st

# Configuração da página
st.set_page_config(
    page_title="i4DATA - Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Cabeçalho principal
st.markdown(
    """
<div style="text-align: center; padding: 2rem 0;">
    <h1 style="color: #1f77b4; font-size: 3.5rem; margin-bottom: 0.5rem;">
        🚀 i4DATA
    </h1>
    <h2 style="color: #666; font-weight: 300; font-size: 1.8rem;">
        Plataforma de Inteligência Preditiva e Análise Regulatória
    </h2>
</div>
""",
    unsafe_allow_html=True,
)

st.markdown("---")

# Sobre o Projeto
st.markdown("""
## 🎯 Sobre o Projeto

**i4DATA** é uma plataforma RegTech modular que correlaciona dados de mercado financeiro 
(ex: ações da B3) com dados setoriais (ex: geração de energia no Ceará) para gerar 
**insights preditivos** e **análises de risco regulatório**.
""")

# Tecnologias
st.markdown("""
## 🛠️ Tecnologias Utilizadas

Esta plataforma foi construída com tecnologias modernas e robustas:
""")

col1, col2 = st.columns(2)

with col1:
    st.markdown("""
    **Análise e Modelagem:**
    - 🐍 **Python 3.11+**
    - 📊 **Pandas & NumPy** - Manipulação de dados
    - 🔮 **Prophet & ARIMA** - Modelos preditivos
    """)

with col2:
    st.markdown("""
    **Dados e Interface:**
    - 🎨 **Streamlit** - Dashboard interativo
    - 📈 **Matplotlib, Seaborn & Plotly** - Visualizações
    - 📁 **ANEEL BIG** - Dados de geração de energia
    """)

st.markdown("---")

# Fontes de Dados
st.markdown("""
## 📊 Fontes de Dados

O projeto integra informações de múltiplas bases de dados públicas:
""")

st.markdown("""
| Fonte | Descrição | Aplicação |
|-------|-----------|-----------|
| ⚡ **ANEEL - BIG** | Dados de geração de energia elétrica | Análise setorial energética |
""")

st.markdown("---")

# Objetivos
st.markdown("""
## 🎓 Objetivos do Projeto

1. **📊 Análise Exploratória de Dados (EDA)** - Compreensão profunda dos dados setoriais
2. **🔮 Séries Temporais e Previsão** - Desenvolvimento de modelos preditivos confiáveis
3. **📈 Dashboard Interativo** - Visualização clara e intuitiva dos insights
4. **💼 Aplicação Prática** - Validação com dados reais e geração de valor

""")

st.markdown("---")

# Resultado Esperado
st.markdown("""
## 🎯 Resultado Esperado

Um **painel visual funcional** que demonstra:

✅ Previsão de geração de energia no Ceará para os próximos meses  
✅ Índice de risco regulatório automatizado e atualizado  
✅ Capacidade de replicação para outros setores (Porto, Finanças, etc.)  
✅ Produto investível e escalável para apresentação a stakeholders  

""")

# Navegação
st.markdown("---")
st.markdown("""
## 🗺️ Navegação

Use o menu lateral para explorar as diferentes seções do dashboard:

- **📊 Análise Exploratória** - Explore os dados e entenda as tendências
- **📈 Dados Históricos** - Visualize séries temporais e padrões
- **🔮 Previsões** - Acesse os modelos preditivos e projeções futuras
- **⚠️ Risco Regulatório** - Analise indicadores de risco e compliance

""")

# Rodapé
st.markdown("---")
st.markdown(
    """
<div style="text-align: center; padding: 2rem 0; color: #666;">
    <p style="font-size: 0.9rem;">
        Desenvolvido com ❤️ pela <strong>Equipe 3.2 e 3.3 - V.A. Barbosa</strong><br>
        <strong>C-Jovem Imersão</strong> | Projeto 01 - Aplicações de Modelos Preditivos e Análise Regulatória
    </p>
    <p style="font-size: 0.85rem; margin-top: 1rem;">
        🚀 <em>Vamos construir análises que geram impacto real!</em> 📊💡
    </p>
</div>
""",
    unsafe_allow_html=True,
)
