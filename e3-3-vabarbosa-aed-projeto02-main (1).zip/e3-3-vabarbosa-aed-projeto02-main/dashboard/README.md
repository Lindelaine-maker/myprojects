# 📊 Dashboard i4DATA

Esta pasta contém os arquivos do painel interativo de visualização de dados.

## 🚀 Como Executar

### Streamlit

```bash
streamlit run Home.py
```

### Dash (alternativo)

```bash
python app_dash.py
```

## 📁 Arquivos

-   `Home.py` - Dashboard principal em Streamlit
-   `app_dash.py` - Dashboard alternativo em Dash (opcional)
-   `components/` - Componentes reutilizáveis do dashboard
-   `assets/` - Imagens, logos e arquivos estáticos

## 🎨 Funcionalidades Planejadas

-   ✅ Visualização de séries temporais
-   ✅ Previsões com Prophet/ARIMA
-   ✅ Índice de risco regulatório
-   ✅ Tabelas interativas
-   🔄 Filtros por período e setor
-   🔄 Exportação de relatórios
-   🔄 Comparação entre múltiplas fontes

## 📝 Notas

O dashboard será desenvolvido de forma incremental ao longo das 10 semanas do projeto.
