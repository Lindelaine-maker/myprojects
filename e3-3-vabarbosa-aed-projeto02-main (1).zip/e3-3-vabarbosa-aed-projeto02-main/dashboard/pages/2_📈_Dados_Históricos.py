import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# Configuração da página
st.set_page_config(
    page_title="i4DATA - Dashboard",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Carregando os dados processados
try:
    df = pd.read_csv("./dashboard/dados.csv")
except FileNotFoundError:
    df = pd.read_csv("dados.csv")

df["data"] = df["data"].apply(lambda x: str(x) + "12" + "31")
df["data"] = pd.to_datetime(df["data"])

if "uf" in df.columns:
    # Obtém a lista única de UFs em ordena alfabetica
    lista_ufs = sorted(df["uf"].unique().tolist())
    # Insere a opção "todos" no início da lista
    lista_ufs.insert(0, "todos")

# Sidebar
with st.sidebar:
    st.header("⚙️ Configurações")

    st.subheader("📍 Unidade Federativa (UF)")
    uf_selecionada = st.selectbox(
        "Selecione o Estado (UF):", lista_ufs
    )

    # Período de análise
    st.subheader("📅 Período")
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Início", df["data"].min())
    with col2:
        end_date = st.date_input("Fim", df["data"].max())

    st.markdown("---")
    st.markdown("### 📊 Sobre o Projeto")
    st.info("""
    MVP desenvolvido pela Equipe 3.2 e 3.3 V.A. Barbosa 
    no programa C-Jovem Imersão.
    """)

# Filtro de período
mask = (df["data"] >= pd.to_datetime(start_date)) & (
    df["data"] <= pd.to_datetime(end_date)
)
df_filtered = df.loc[mask]
if uf_selecionada != "todos" and "uf" in df_filtered.columns:
        df_filtered = df_filtered[df_filtered["uf"] == uf_selecionada]

st.header("📈 Dados Históricos")
    
if df_filtered is not None and not df_filtered.empty:
    # Métricas principais
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("Total de Registros", f"{len(df_filtered):,}", delta=None)

    with col2:
        if "geracao_MWh" in df_filtered.columns:
            media = df_filtered["geracao_MWh"].mean()
            st.metric("Média MWh", f"{media:,.0f}")

    with col3:
        if "geracao_MWh" in df_filtered.columns:
            total = df_filtered["geracao_MWh"].sum()
            st.metric("Total MWh", f"{total:,.0f}")

    with col4:
        variacao = (
        (
            df_filtered.groupby(["data"])["geracao_MWh"]
            .sum()
            .reset_index()["geracao_MWh"]
            .iloc[-1]
            / df_filtered.groupby(["data"])["geracao_MWh"]
            .sum()
            .reset_index()["geracao_MWh"]
            .iloc[0]
        )- 1
        )
        variacao = round(variacao, 2)
        st.metric("Variação %", f"{variacao}%", delta=f"{variacao}%")

    # Gráfico de linha
    st.subheader("Série Temporal")
    fig = px.line(
        df_filtered.groupby("data", as_index=False)["geracao_MWh"].sum(),
        x="data",
        y="geracao_MWh",
        title="Geração de Energia ao Longo do Tempo",
        labels={"data": "Data", "geracao_MWh": "Geração (MWh)"},
    )
    fig.update_layout(height=400)
    st.plotly_chart(fig, use_container_width=True)

    # Mostrar dados em tabela
    with st.expander("📋 Ver Dados"):
        st.dataframe(df_filtered, use_container_width=True)
else:
    st.warning("⚠️ Dados não encontrados. Execute os scripts ETL primeiro.")
    st.code("python codigos/etl.py", language="bash")

# Supondo que 'df_historico' é o seu DataFrame na página de dados históricos
# É CRUCIAL garantir que a coluna 'data' seja do tipo datetime antes de usar o Plotly
# Se não for, converta:
# df_historico['data'] = pd.to_datetime(df_historico['data'])


# --- Histograma de Data (Série Temporal Agregada) ---

title_date_hist = "Volume de Geração (MWh) ao Longo do Tempo"

fig_date_hist = px.histogram(
    df_filtered,
    x="data",             # O eixo X é a coluna de data/tempo
    y="geracao_MWh",      # A altura das barras será a soma de 'geracao_MWh'
    histfunc="sum",       # Define a função de agregação como Soma
    title=title_date_hist,
    labels={
        "data": "Período (Agrupado por Ano/Mês)",
        "y": "Geração Total (MWh)",
        "count": "Total de Geração (MWh)"
    },
    color_discrete_sequence=['#4285F4'],  # Cor para contraste
    template="plotly_dark",
)

# Ajustes: O Plotly escolhe automaticamente o melhor 'bin' (mês, ano, etc.). 
# Para forçar, se necessário (ex: agrupar por mês, se os dados permitirem):
# fig_date_hist.update_traces(xbins_size="M1") 

fig_date_hist.update_layout(
    xaxis_title="Tempo",
    yaxis_title="Geração Total Acumulada (MWh)",
    hovermode="x unified",
    font=dict(family="Arial, sans-serif", size=12, color="white"),
    plot_bgcolor="black",
    paper_bgcolor="black",
)

st.plotly_chart(fig_date_hist, use_container_width=True)

# --- Histograma de Distribuição com Separação Categórica ---

title_comp_hist = "Distribuição da Geração (MWh) por Fonte de Energia"

fig_comp_hist = px.histogram(
    df_filtered,
    x="geracao_MWh",
    color="fonte_energia", # Separa as barras por Fonte de Energia
    title=title_comp_hist,
    marginal="box", # Adiciona um Box Plot marginal para cada fonte
    barmode='overlay', # Sobrepõe as barras para facilitar a comparação
    opacity=0.7, # Adiciona transparência para ver as sobreposições
    labels={
        "geracao_MWh": "Geração (MWh)",
        "count": "Frequência de Eventos",
    },
    template="plotly_dark",
)

fig_comp_hist.update_layout(
    font=dict(family="Arial, sans-serif", size=12, color="white"),
    plot_bgcolor="black",
    paper_bgcolor="black",
)

st.plotly_chart(fig_comp_hist, use_container_width=True)