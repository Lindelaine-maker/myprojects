import pandas as pd
import plotly.express as px

# Nome do arquivo carregado
file_name = r"C:\Users\Paulo Victor\Desktop\trabalo cjovem2025\e3-3-vabarbosa-aed-projeto02\dados\processed\dados-geracao-injecao.csv"
# Nomes das colunas que você deseja manter (Distribuidora e Geração)
colunas_para_filtrar = ['distribuidora', 'geracao_MWh']

# --- 1. Carregar o arquivo CSV e Filtrar Colunas ---
print(f"Carregando e filtrando dados do arquivo: {file_name}")
try:

    df_filtrado = pd.read_csv(file_name, usecols=colunas_para_filtrar)
except FileNotFoundError:
    print(f"Erro: O arquivo {file_name} não foi encontrado.")
    exit()
except ValueError as e:
    print(f"Erro ao ler colunas: {e}. Verifique se as colunas estão corretas.")
    exit()

# --- 2. Preparação de Dados e Contagem de Linhas ---
# Captura o número de linhas
row_count = len(df_filtrado)

# Agrupar os dados e somar a Geração (MWh) por Distribuidora
agregado_distribuidoras = df_filtrado.groupby('distribuidora')['geracao_MWh'].sum()

# Selecionar as 10 empresas com a maior produção
top_10_distribuidoras = agregado_distribuidoras.sort_values(ascending=False).head(10).reset_index()
top_10_distribuidoras.columns = ['Distribuidora', 'Geração Total (MWh)']

# --- 3. Criar o gráfico de barras interativo com Plotly Express (Tema Escuro) ---
title_text = '⚡ Top 10 Distribuidoras por Geração Total de Energia (MWh)'

fig = px.bar(
    top_10_distribuidoras,
    x='Distribuidora',
    y='Geração Total (MWh)',
    title=title_text,
    labels={
        'Distribuidora': 'Distribuidora de Energia',
        'Geração Total (MWh)': 'Geração Acumulada (MWh)'
    },
    color='Geração Total (MWh)',
    color_continuous_scale=px.colors.sequential.Turbo_r,
    template='plotly_dark'
)

# --- 4. Ajustar o layout e ADICIONAR A ANOTAÇÃO (Legenda) ---
fig.update_layout(
    xaxis={'categoryorder':'total descending'},
    hovermode="x unified",
    font=dict(
        family="Arial, sans-serif",
        size=12,
        color="white"
    ),
    title_font_color="white",
    title_font_size=18,
    plot_bgcolor='black',
    paper_bgcolor='black',

    # NOVIDADE: Adiciona a contagem de linhas como uma anotação de rodapé
    annotations=[
        dict(
            text=f"Fonte: Dados de {row_count} linhas utilizadas para a análise.", # O texto da anotação
            showarrow=False, # Não mostra seta apontando para o gráfico
            xref="paper",  # Referência horizontal: posição relativa ao "papel" do gráfico
            yref="paper",  # Referência vertical: posição relativa ao "papel" do gráfico
            x=0.0,         # Posição X (0.0 = canto esquerdo)
            y=-0.2,        # Posição Y (abaixo do eixo X, ajuste este valor se necessário)
            font=dict(
                size=10,
                color="lightgray" # Cor mais discreta
            ),
            align="left"
        )
    ]
)

# --- 5. Ajuste fino das barras e eixos (Cores do Grid) ---
fig.update_traces(
    marker_line_width=0,
    opacity=0.9
)
fig.update_xaxes(
    showgrid=False,
    color="lightgray"
)
fig.update_yaxes(
    showgrid=True,
    gridcolor='gray',
    color="lightgray"
)

# --- 6. Exibir o gráfico ---
fig.show()