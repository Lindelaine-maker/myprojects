import streamlit as st
import pandas as pd
import plotly.graph_objects as go

# Caminho do arquivo
caminho = r"C:\Users\PARTICULAR\Documents\GitHub\dados-geracao-injecao.csv"

# Carrega CSV
df = pd.read_csv(caminho)

# Nomes das colunas
col_fonte = "fonte_energia"
col_energia = "geracao_MWh"

# Remove espaços extras e caracteres estranhos
df.columns = df.columns.str.strip()
df[col_fonte] = df[col_fonte].astype(str).str.strip()

# Força conversão numérica
df[col_energia] = (
    df[col_energia]
    .astype(str)
    .str.replace(",", ".", regex=False)
    .str.replace(" ", "", regex=False)
)

df[col_energia] = pd.to_numeric(df[col_energia], errors="coerce").fillna(0)

# Agrupamento
df_grouped = (
    df.groupby(col_fonte)[col_energia]
    .sum()
    .sort_values(ascending=False)
    .reset_index()
)

# Cálculo das porcentagens
total = df_grouped[col_energia].sum()
df_grouped["percentual"] = (df_grouped[col_energia] / total) * 100

# Dados para o gráfico 2 (barras verticais)
labels = df_grouped[col_fonte].tolist()
values = df_grouped["percentual"].tolist()

# Paleta de cores neon suave
cores_neon_suave = [
    "#7DF9FF", "#FF77FF", "#39FF14", "#F6FF00",
    "#FFAA33", "#00E5FF"
] * 5

# Gráfico 2 (Barras verticais neon)
fig_barras = go.Figure(
    data=[
        go.Bar(
            x=labels,
            y=values,
            marker_color=cores_neon_suave[:len(labels)],
            text=[f"{v:.2f}%" for v in values],
            textposition="auto",
            hovertemplate="<b>%{x}</b><br>%{y:.2f}%<extra></extra>",
        )
    ]
)

fig_barras.update_layout(
    title=dict(
        text="Fontes de Energia - Distribuição em Barras",
        font=dict(size=22, family="Arial", color="#f4f8e6"),
        x=0.0,
        xanchor="left",
    ),
    xaxis=dict(
        title="Fonte de Energia",
        showgrid=False,
        linecolor="#444444",
        tickfont=dict(color="#FFFFFF"),
        title_font=dict(color="#f4f8e6")
    ),
    yaxis=dict(
        title="Porcentagem (%)",
        gridcolor="#444444",
        linecolor="#444444",
        tickfont=dict(color="#FFFFFF"),
        title_font=dict(color="#f4f8e6")
    ),
    paper_bgcolor="#131313",
    plot_bgcolor="#131313",
    margin=dict(t=80, b=20, l=20, r=20),
    font=dict(color="#FFFFFF")
)

# Exibir no Streamlit
st.plotly_chart(fig_barras, use_container_width=True)

