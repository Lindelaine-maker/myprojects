import plotly.graph_objects as go

labels = ["Fotovoltaica", "Termelétrica", "Eólica", "Hidro"]
values = [93.64, 4.32, 1.18, 0.86]

cores_neon_suave = ["#509e41", "#c02c20", "#304878", "#e88700"]

fig = go.Figure(
    data=[
        go.Pie(
            labels=labels,
            values=values,
            textinfo="percent+label",
            textfont=dict(color="#FFFFFF"),   # <<< letras brancas
            marker=dict(colors=cores_neon_suave),
            hoverinfo="label+percent+value",
            hole=0
        )
    ]
)

fig.update_layout(
    title=dict(
        text="Gráfico de Pizza — Fontes de Energia",
        font=dict(size=22, family="Arial", color="#f4f8e6"),
        x=0.0,
        xanchor="left"
    ),
    legend=dict(
        orientation="v",
        x=1.02,
        y=0.95,
        font=dict(size=12, color="#FFFFFF")  # legenda branca
    ),
    paper_bgcolor="#131313",
    plot_bgcolor="#131313",
    margin=dict(t=80, b=20, l=20, r=150)
)

fig.show()